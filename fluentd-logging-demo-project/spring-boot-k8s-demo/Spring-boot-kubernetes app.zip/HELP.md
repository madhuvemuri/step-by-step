# Getting Started

### Commands Spring boot application deploying in kubernetes 
If you are using minikube you need to you need to run the tunner to get the cluster acces out side the cluster

`minikube tunnel`

   1. **Run the bellow command to build the jar** 

      **`mvn clean install`**

   2. **Build the docker image** (Refer Dockerfile)

      `docker build -t zerv-demo .`
   3. **Tag the docker image**

      `docker tag zerv-demo madhuv/zerv-demo`

   4. **Push the docker image to docker repo** 

    _(Before that run `docker login` command and enter docker credentials)_

    docker push madhuv/zerv-demo

   5. **Deploy the spring boot app** (Refer demo.yaml)

      `kubectl apply -f demo.yaml`

   [http://localhost:8080/info](http://localhost:8080/info)
   [http://localhost:8080/trace](http://localhost:8080/trace)




